<?php if ( ! defined( 'ABSPATH' ) ) exit;

return array(
	'metadata210beta1'     => 'metadata210beta1',
	'memberdir210beta1'    => 'memberdir210beta1',
);