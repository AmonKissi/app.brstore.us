<div id="getting-started" class="gt-tab-pane gt-is-active">
	<p class="about-description"><?php esc_html_e( 'Please follow this video tutorial to get started with Meta Box and extensions:', 'meta-box' ); ?></p>
	<div class="youtube-video-container">
		<iframe width="560" height="315" src="https://www.youtube.com/embed/M0nEF7b0woU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>
</div>
