(function ($) {
    $(document).ready(function () {
        $('.kata-preloader-screen').fadeOut(400);
    });
})(jQuery);