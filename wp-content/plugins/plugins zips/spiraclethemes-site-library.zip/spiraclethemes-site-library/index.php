<?php
/**
 * Silence is golden
 *
 * @package  spiraclethemes-site-library
 * @author   Spiraclethemes
 */